# 飲食順序創意決策助理

飲食時序 × 目標導向的 AI 互動決策工具。

## 本地開發

1. 安裝依賴：`npm install`
2. 複製 `.env.example` 為 `.env`，填入你的 Gemini API Key：
   ```
   GEMINI_API_KEY=你的金鑰
   ```
3. 啟動：`npm run dev`

## 部署到 Railway（免費）

### 步驟一：取得 Gemini API Key
前往 [Google AI Studio](https://aistudio.google.com/apikey) 免費取得。

### 步驟二：上傳到 GitHub
1. 到 [github.com](https://github.com) 建立新的 private repo
2. 把這個資料夾的所有檔案上傳進去（注意：不要上傳 `.env` 檔案）

### 步驟三：部署到 Railway
1. 到 [railway.app](https://railway.app) 用 GitHub 帳號登入
2. 點 **New Project → Deploy from GitHub repo**
3. 選擇你剛建立的 repo
4. 部署成功後，點左側 **Variables** 頁籤，新增：
   - Key: `GEMINI_API_KEY`
   - Value: 你的 Gemini API Key
5. Railway 會自動重新部署，完成後點 **Settings → Networking → Generate Domain** 取得網址

完成！你的 App 就上線了 🎉

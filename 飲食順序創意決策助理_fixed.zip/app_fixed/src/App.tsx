import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Activity, 
  Apple, 
  Droplet, 
  Brain, 
  Sparkles, 
  Plus, 
  Check, 
  Trash2, 
  ArrowRight, 
  LayoutGrid, 
  Flame, 
  RotateCcw, 
  ChevronRight, 
  X, 
  Info,
  CalendarDays,
  UtensilsCrossed,
  Hourglass,
  Lightbulb,
  Heart
} from "lucide-react";
import { GoalType, TimelinePhase, CategoryKey, RecommendationResponse } from "./types";
import { defaultInteractions } from "./data";

export default function App() {
  const [selectedGoal, setSelectedGoal] = useState<GoalType>("健康");
  const [viewMode, setViewMode] = useState<"arrow" | "matrix">("arrow");
  
  // Custom AI Recommended sequence, defaults to null unless AI triggers it
  const [customData, setCustomData] = useState<RecommendationResponse | null>(null);
  
  // AI Form inputs
  const [userProfile, setUserProfile] = useState("");
  const [currentHabit, setCurrentHabit] = useState("");
  const [loadingAI, setLoadingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Active detailed inspection modal state
  const [inspectorCell, setInspectorCell] = useState<{
    phase: TimelinePhase;
    category: CategoryKey;
  } | null>(null);

  // My Custom Habit Tracker (stored in localStorage)
  interface HabitItem {
    id: string;
    text: string;
    phase: string;
    goal: string;
    completed: boolean;
  }
  const [habits, setHabits] = useState<HabitItem[]>([]);

  // Load habits from localStorage on startup
  useEffect(() => {
    const saved = localStorage.getItem("dietary_habits");
    if (saved) {
      try {
        setHabits(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse habits", e);
      }
    } else {
      // Pre-populate with beautiful initial target habits
      const initial: HabitItem[] = [
        { id: "1", text: "吃飯前 30 分鐘徐徐飲用溫熱大麥茶 300ml", phase: "吃飯前", goal: "健康", completed: false },
        { id: "2", text: "進餐乾濕分離（吃飯時不大量喝冰水以保障胃酸活性）", phase: "吃飯中", goal: "健康", completed: false },
        { id: "3", text: "餐後 20 分鐘享受 1 小片 85% 黑巧克力，向大腦宣告進食結束", phase: "吃飯後", goal: "健康", completed: false }
      ];
      setHabits(initial);
      localStorage.setItem("dietary_habits", JSON.stringify(initial));
    }
  }, []);

  // Save habits to localStorage helper
  const saveHabits = (updated: HabitItem[]) => {
    setHabits(updated);
    localStorage.setItem("dietary_habits", JSON.stringify(updated));
  };

  const handleAddHabit = (text: string, phaseName: string, goalName: string) => {
    if (!text.trim()) return;
    const newHabit: HabitItem = {
      id: Date.now().toString(),
      text,
      phase: phaseName,
      goal: goalName,
      completed: false
    };
    saveHabits([newHabit, ...habits]);
  };

  const handleToggleHabit = (id: string) => {
    const updated = habits.map(h => h.id === id ? { ...h, completed: !h.completed } : h);
    saveHabits(updated);
  };

  const handleDeleteHabit = (id: string) => {
    const updated = habits.filter(h => h.id !== id);
    saveHabits(updated);
  };

  // AI Recommendation Trigger
  const handleGetAIRecommendation = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoadingAI(true);
    setAiError(null);

    try {
      const response = await fetch("/api/recommend", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          goal: selectedGoal,
          userProfile: userProfile,
          currentHabit: currentHabit,
        }),
      });

      if (!response.ok) {
        throw new Error("伺服器或是 AI 端點回應失敗。");
      }

      const data: RecommendationResponse = await response.json();
      setCustomData(data);
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "無法載入客製化推薦，已為您展現精選黃金組合。");
    } finally {
      setLoadingAI(false);
    }
  };

  const handleResetToDefault = () => {
    setCustomData(null);
    setUserProfile("");
    setCurrentHabit("");
    setAiError(null);
  };

  // Preset prompts for quick trials
  const presets = [
    {
      goal: "健康" as GoalType,
      profile: "我是一名行銷主管，下午 3 到 4 點常覺得昏沉，肚子一餓就容易胃痛，但吃正餐又消化不良常胃脹氣。",
      habit: "常在下午喝連鎖店的冰無糖綠茶填肚子，吃飯常在10分鐘內快速吃完。"
    },
    {
      goal: "減重" as GoalType,
      profile: "正在執行 16:8 斷食。晚餐時常控制不住飢餓感，前菜跟肉吃了很快，且吃完正餐強烈渴望來點手搖杯精緻甜食。",
      habit: "習慣吃飯期間配一碗大骨熱高湯；一餐快結束時，會拿起隨餐的水果狂吃。"
    },
    {
      goal: "情緒" as GoalType,
      profile: "工作壓力奇大，晚上加班回家後，常常精疲力竭只想暴食高鈉洋芋片，或者喝罐啤酒舒緩神經，睡眠品質極差。",
      habit: "加班時習慣嚼嚼含糖薄荷糖心，並在睡覺前吃冰香蕉和蘇打餅乾，企圖助眠。"
    }
  ];

  const applyPreset = (preset: typeof presets[0]) => {
    setSelectedGoal(preset.goal);
    setUserProfile(preset.profile);
    setCurrentHabit(preset.habit);
  };

  // Active working dataset (either customized AI response or pure expert local database)
  const isCustomActive = customData !== null && customData.goal === selectedGoal;
  
  const staticData = defaultInteractions[selectedGoal];
  
  // Amalgamate the UI content
  const timelineContent = isCustomActive && customData
    ? customData.timeline
    : staticData.timeline;

  const currentSummary = isCustomActive && customData
    ? customData.analysis
    : staticData.summary;

  const currentHacks = isCustomActive && customData
    ? customData.hacks
    : staticData.hacks;

  const currentMotto = isCustomActive && customData
    ? customData.moodBooster
    : staticData.moodBooster;

  // Render Theme Color utilities depending on the active goal
  const getGoalColorClasses = (goal: GoalType) => {
    switch (goal) {
      case "健康":
        return {
          primary: "emerald",
          bg: "bg-emerald-500",
          border: "border-emerald-500",
          text: "text-emerald-700",
          textDark: "text-emerald-900",
          lightBg: "bg-emerald-50/50",
          cardHover: "hover:border-emerald-300 hover:shadow-emerald-100/50",
          badge: "bg-emerald-100 text-emerald-800",
          accentGradient: "from-emerald-500 to-teal-600",
          ring: "focus:ring-emerald-500",
          btnActive: "bg-emerald-600 text-white shadow-lg shadow-emerald-200"
        };
      case "減重":
        return {
          primary: "amber",
          bg: "bg-amber-500",
          border: "border-amber-500",
          text: "text-amber-700",
          textDark: "text-amber-900",
          lightBg: "bg-amber-50/50",
          cardHover: "hover:border-amber-300 hover:shadow-amber-100/50",
          badge: "bg-amber-100 text-amber-800",
          accentGradient: "from-amber-500 to-orange-600",
          ring: "focus:ring-amber-500",
          btnActive: "bg-amber-600 text-white shadow-lg shadow-amber-200"
        };
      case "情緒":
        return {
          primary: "rose",
          bg: "bg-rose-500",
          border: "border-rose-500",
          text: "text-rose-700",
          textDark: "text-rose-900",
          lightBg: "bg-rose-50/50",
          cardHover: "hover:border-rose-300 hover:shadow-rose-100/50",
          badge: "bg-rose-100 text-rose-800",
          accentGradient: "from-rose-500 to-pink-600",
          ring: "focus:ring-rose-500",
          btnActive: "bg-rose-600 text-white shadow-lg shadow-rose-200"
        };
    }
  };

  const currentTheme = getGoalColorClasses(selectedGoal);

  // Mapping phases and categories dictionary
  const phaseLabels = {
    beforeMeal: { label: "吃飯前", time: "進正餐前 15~30 分鐘", emoji: "🕰️" },
    duringMeal: { label: "吃飯中", time: "進食主要餐點期間", emoji: "🍽️" },
    afterMeal: { label: "吃飯後", time: "餐後 20 分鐘與其後一小時", emoji: "🌅" }
  };

  const categoryLabels = {
    snacks: { label: "零食", emoji: "🍿", color: "text-purple-600" },
    water: { label: "喝水", emoji: "💧", color: "text-blue-600" },
    fruit: { label: "水果", emoji: "🍎", color: "text-red-500" }
  };

  // Helper to retrieve specific cell content dynamically
  const getCellContent = (phase: TimelinePhase, category: CategoryKey) => {
    const pData = timelineContent[phase];
    if (category === "snacks") {
      return { title: pData.snacks, desc: pData.snacksDesc };
    } else if (category === "water") {
      return { title: pData.water, desc: pData.waterDesc };
    } else {
      return { title: pData.fruit, desc: pData.fruitDesc };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 selection:bg-sky-100 pb-16 antialiased font-sans">
      
      {/* Visual Header Grid banner */}
      <header className="relative overflow-hidden bg-white border-b border-slate-100 pt-10 pb-8 shadow-sm">
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-emerald-50 to-sky-50 rounded-full blur-3xl opacity-60 -mr-20 -mt-20 pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-96 h-96 bg-gradient-to-tr from-pink-50 to-amber-50 rounded-full blur-3xl opacity-50 -ml-40 -mb-40 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 text-slate-800 rounded-full text-xs font-semibold tracking-wide mb-3">
                <UtensilsCrossed className="w-3 h-3 text-slate-600" />
                <span>時間生物學與食材組合對照系統</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold font-display text-slate-900 tracking-tight leading-none">
                膳食序 <span className="text-slate-500 font-normal">|</span> 飲食順序創意決策助理
              </h1>
              <p className="mt-2 text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
                利用<strong>「吃飯前、吃飯中、吃飯後」</strong>的時間軸（X軸為具有時間順序的流程步序），
                結合<strong>「零食、喝水、水果」</strong>（Y軸）進行創意重組，全力支持您的減重目標、健康恆定與情緒穩定。
              </p>
            </div>
            
            <div className="flex flex-col xs:flex-row items-stretch md:items-center gap-3">
              <button
                onClick={() => setViewMode("arrow")}
                className={`px-4 py-2 text-sm font-medium rounded-lg flex items-center justify-center gap-2 transition duration-200 border ${
                  viewMode === "arrow"
                    ? "bg-slate-900 text-white border-slate-900 shadow-md"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
                id="view-mode-arrow-btn"
              >
                <ChevronRight className="w-4 h-4 rotate-0" />
                <span>互動式箭形流向圖</span>
              </button>
              <button
                onClick={() => setViewMode("matrix")}
                className={`px-4 py-2 text-sm font-medium rounded-lg flex items-center justify-center gap-2 transition duration-200 border ${
                  viewMode === "matrix"
                    ? "bg-slate-900 text-white border-slate-900 shadow-md"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
                id="view-mode-matrix-btn"
              >
                <LayoutGrid className="w-4 h-4" />
                <span>創意時序對照決策表</span>
              </button>
            </div>
          </div>

          {/* Core Goals Toggles */}
          <div className="mt-8 border-t border-slate-100 pt-6">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
              第一步：選擇主要優化健康之坐標維度
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(["健康", "減重", "情緒"] as GoalType[]).map((goal) => {
                const colors = getGoalColorClasses(goal);
                const isSelected = selectedGoal === goal;
                return (
                  <button
                    key={goal}
                    onClick={() => {
                      setSelectedGoal(goal);
                      // Clear customData when moving between goals, or keep if matches
                    }}
                    className={`relative overflow-hidden p-4 rounded-xl border text-left transition-all duration-300 ${
                      isSelected
                        ? `${colors.border} bg-white shadow-md ring-2 ring-offset-2 ${colors.ring}`
                        : "border-slate-200 bg-white/70 hover:border-slate-300 hover:bg-white"
                    }`}
                    id={`goal-toggle-${goal}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold tracking-wider text-slate-400 capitalize">DIMENSION</span>
                      <span className={`w-2 h-2 rounded-full ${isSelected ? colors.bg : "bg-slate-300"}`} />
                    </div>
                    <div className="mt-2 flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isSelected ? colors.bg + " text-white" : "bg-slate-100 text-slate-500"}`}>
                        {goal === "健康" && <Activity className="w-5 h-5" />}
                        {goal === "減重" && <Flame className="w-5 h-5" />}
                        {goal === "情緒" && <Brain className="w-5 h-5" />}
                      </div>
                      <div>
                        <h4 className="text-base font-bold text-slate-950 font-display">
                          {goal}
                        </h4>
                        <p className="text-xs text-slate-500">
                          {goal === "健康" && "生理、血糖與酵素激活健康指引"}
                          {goal === "減重" && "防阻果糖堆積與低熱充盈阻遏"}
                          {goal === "情緒" && "快樂與安穩遞質(血清素)營養調御"}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        
        {/* Dynamic Status bar indicating whether AI or Local default is running */}
        <div className="mb-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between p-3.5 rounded-xl border bg-white shadow-xs gap-3">
          <div className="flex items-center gap-3">
            <span className={`flex h-3 w-3 relative ${isCustomActive ? "hidden" : "flex"}`}>
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <div className={`flex items-center justify-center p-1.5 rounded-md ${isCustomActive ? "bg-indigo-100 text-indigo-700" : "bg-emerald-100 text-emerald-700"}`}>
              {isCustomActive ? <Sparkles className="w-4 h-4 animate-spin-slow" /> : <Activity className="w-4 h-4" />}
            </div>
            <div>
              <span className="text-xs text-slate-400 font-semibold block uppercase">DECISION PREVIEW STATUS</span>
              <span className="text-sm font-bold text-slate-900">
                {isCustomActive ? `🤖 自訂 AI 專屬飲食時序：針對「${selectedGoal}」規劃` : `🥗 黃金生化原理基礎規劃 (預設模式 | 鎖定「${selectedGoal}」)`}
              </span>
            </div>
          </div>
          {isCustomActive && (
            <button
              onClick={handleResetToDefault}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition"
              id="reset-to-default-btn"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>還原經典營養配置</span>
            </button>
          )}
        </div>

        {/* Selected Strategy summary block */}
        <div className={`p-6 rounded-2xl border bg-white mb-8 shadow-sm relative overflow-hidden`}>
          <div className={`absolute top-0 left-0 w-1.5 h-full ${currentTheme.bg}`} />
          <h2 className="text-lg font-bold text-slate-900 mb-2 flex items-center gap-2">
            <Info className={`w-5 h-5 ${currentTheme.text}`} />
            <span>核心飲食序思維（創意思考與生理機制）</span>
          </h2>
          <p className="text-slate-600 text-sm leading-relaxed max-w-5xl">
            {currentSummary}
          </p>
        </div>

        {/* ----------------- VIEW 1: DYNAMIC HORIZONTAL ARROW FLOW DIAGRAM ----------------- */}
        {viewMode === "arrow" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <ChevronRight className={`w-5 h-5 transform rotate-45 ${currentTheme.text}`} />
                <span>1. 吃飯時序：箭形流動路徑 (X軸順序)</span>
              </h2>
              <span className="text-xs text-slate-500 hidden sm:inline">提示：依時間軸由左往右循序執行，點擊卡片瀏覽食譜與生理機制</span>
            </div>

            {/* Arrow Diagram Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative">
              
              {/* Sequential Time Blocks */}
              {(["beforeMeal", "duringMeal", "afterMeal"] as TimelinePhase[]).map((phase, idx) => {
                const phaseMeta = phaseLabels[phase];
                const activeCategoryKeys: CategoryKey[] = ["snacks", "water", "fruit"];
                
                return (
                  <div key={phase} className="relative group">
                    {/* Visual Connection Chevron arrow for Large Screens */}
                    {idx < 2 && (
                      <div className="hidden lg:flex absolute top-1/2 -right-4.5 transform -translate-y-1/2 z-10 text-slate-300">
                        <ChevronRight className="w-9 h-9" />
                      </div>
                    )}

                    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs group-hover:shadow-md transition-shadow duration-300">
                      
                      {/* Phase Header */}
                      <div className={`p-4 ${currentTheme.lightBg} border-b border-slate-100 flex items-center justify-between`}>
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl">{phaseMeta.emoji}</span>
                          <div>
                            <span className="text-xs text-slate-400 font-bold uppercase block">STEP 0{idx + 1}</span>
                            <h3 className="text-base font-bold text-slate-950 font-display flex items-center gap-1.5">
                              {phaseMeta.label}
                            </h3>
                          </div>
                        </div>
                        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${currentTheme.badge}`}>
                          {phaseMeta.time}
                        </span>
                      </div>

                      {/* Y-Axis Components mapped to standard blocks */}
                      <div className="p-4 space-y-4">
                        {activeCategoryKeys.map((catKey) => {
                          const catMeta = categoryLabels[catKey];
                          const cell = getCellContent(phase, catKey);

                          return (
                            <div 
                              key={catKey}
                              onClick={() => setInspectorCell({ phase, category: catKey })}
                              className={`p-3.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white transition-all duration-200 cursor-pointer border-l-2 border-l-slate-300 hover:border-l-4 hover:border-l-${selectedGoal === "健康" ? "emerald" : selectedGoal === "減重" ? "amber" : "rose"}-500 ${currentTheme.cardHover}`}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-sm">{catMeta.emoji}</span>
                                  <span className="text-xs text-slate-400 font-bold uppercase">{catMeta.label} (Y軸)</span>
                                </div>
                                <span className="text-[10px] text-slate-400 group-hover:text-amber-500 font-mono">點擊解鎖學理</span>
                              </div>
                              <h4 className="text-sm font-bold text-slate-950 line-clamp-1 mb-1">
                                {cell.title}
                              </h4>
                              <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                                {cell.desc}
                              </p>
                            </div>
                          );
                        })}
                      </div>

                      {/* Sequential Instruction Hint Footer */}
                      <div className="bg-slate-50 px-4 py-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                        <div className="flex items-center gap-1">
                          <Hourglass className="w-3 h-3 text-slate-400" />
                          <span>重要性：餐前準備與消化酶啟動</span>
                        </div>
                        <span>順序優先級 ➊</span>
                      </div>

                    </div>
                  </div>
                );
              })}

            </div>
          </div>
        )}

        {/* ----------------- VIEW 2: DIETARY DECISION GRID / MATRIX COMPARISON TABLE ----------------- */}
        {viewMode === "matrix" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <LayoutGrid className={`w-5 h-5 ${currentTheme.text}`} />
                <span>2. 創意時序對照決策表 (XY矩陣圖)</span>
              </h2>
              <span className="text-xs text-slate-500 hidden sm:inline">橫向為 X軸（時間順序），縱向為 Y軸（零食、喝水、水果食譜）</span>
            </div>

            {/* Matrix Table Responsive Wrapper */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[750px] border-collapse bg-white">
                  
                  {/* Table Header containing X-Axis */}
                  <thead>
                    <tr className="bg-slate-50/70 border-b border-slate-100">
                      
                      {/* Left Corner coordinate descriptor */}
                      <th className="py-5 px-6 shrink-0 w-52 bg-slate-100/50 border-r border-slate-200 text-left">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                            <span>Y軸: 食材分類 ▽</span>
                          </div>
                          <div className="mt-1 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                            <span>X軸: 時序流程 ▷</span>
                          </div>
                        </div>
                      </th>

                      {/* Eating Phases Headers (X-Axis in Order) */}
                      {(["beforeMeal", "duringMeal", "afterMeal"] as TimelinePhase[]).map((phase, idx) => {
                        const phaseMeta = phaseLabels[phase];
                        return (
                          <th key={phase} className="py-5 px-6 text-left border-r border-slate-100 min-w-[200px]">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xl">{phaseMeta.emoji}</span>
                                <div className="text-left">
                                  <span className="text-[10px] text-slate-400 font-bold block uppercase">STAGE 0{idx + 1}</span>
                                  <h4 className="text-sm font-extrabold text-slate-900">{phaseMeta.label}</h4>
                                </div>
                              </div>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-medium">
                                {idx === 0 ? "起點" : idx === 1 ? "中繼" : "尾聲"}
                              </span>
                            </div>
                            <p className="mt-1 text-left text-[11px] font-normal text-slate-500">
                              {phaseMeta.time}
                            </p>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>

                  {/* Table Body containing Y-Axis Rows and interactive Cells */}
                  <tbody>
                    {(["snacks", "water", "fruit"] as CategoryKey[]).map((catKey) => {
                      const catMeta = categoryLabels[catKey];
                      return (
                        <tr key={catKey} className="border-b border-slate-100 last:border-b-0 hover:bg-slate-50/30 transition-colors">
                          
                          {/* Y-Axis Label Header */}
                          <td className="py-6 px-6 font-semibold bg-slate-50/50 border-r border-slate-200 align-middle">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{catMeta.emoji}</span>
                              <div>
                                <span className="text-sm font-bold text-slate-900 capitalize block">{catMeta.label}</span>
                                <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">SEQUENCE VECTORS</span>
                              </div>
                            </div>
                          </td>

                          {/* 3 Phases Cells for this Category */}
                          {(["beforeMeal", "duringMeal", "afterMeal"] as TimelinePhase[]).map((phase) => {
                            const cell = getCellContent(phase, catKey);
                            return (
                              <td 
                                key={phase} 
                                onClick={() => setInspectorCell({ phase, category: catKey })}
                                className="p-4 border-r border-slate-100 hover:bg-white transition-all duration-200 cursor-pointer group"
                              >
                                <div className={`p-3 rounded-xl border border-transparent group-hover:border-${currentTheme.primary}-200 bg-slate-50/40 group-hover:bg-white group-hover:shadow-xs transition-all duration-200 h-full flex flex-col justify-between min-h-[96px]`}>
                                  <div>
                                    <h5 className="text-sm font-bold text-slate-950 group-hover:text-slate-900 line-clamp-1 mb-1">
                                      {cell.title}
                                    </h5>
                                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                                      {cell.desc}
                                    </p>
                                  </div>
                                  <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <span className="flex items-center gap-1">
                                      <Info className="w-3 h-3" />
                                      <span>檢視機制學理</span>
                                    </span>
                                    <ChevronRight className="w-3.5 h-3.5" />
                                  </div>
                                </div>
                              </td>
                            );
                          })}

                        </tr>
                      );
                    })}
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        )}

        {/* -------------------- SECTION 3: CREATIVE HACKS & GOAL REMINDERS -------------------- */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Creative Behavioral Hacks Column */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-950 flex items-center gap-2 mb-4">
                <Lightbulb className="w-5 h-5 text-amber-500" />
                <span>時序實踐：三大創意行為科學妙招</span>
              </h3>
              <div className="space-y-4">
                {currentHacks.map((hack, hIdx) => (
                  <div key={hIdx} className="flex gap-3 items-start p-3 rounded-xl bg-slate-50 text-xs sm:text-sm text-slate-700 leading-relaxed border border-slate-100">
                    <span className="flex-shrink-0 flex items-center justify-center w-5 h-5 bg-white rounded-full shadow-xs border text-slate-500 font-bold text-[10px]">
                      {hIdx + 1}
                    </span>
                    <span className="flex-1">{hack}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-3">
              <span className="text-2xl flex-shrink-0">🍀</span>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                習慣養成研究（Habit Loop）指出：將飲食順序具象化為時序，比單純忍耐飢餓的成功率<strong>高出 58%</strong>。
              </p>
            </div>
          </div>

          {/* Golden Motto Graphic Card */}
          <div className="relative overflow-hidden p-8 rounded-2xl border border-slate-200 bg-slate-950 text-white shadow-md flex flex-col justify-between min-h-[300px]">
            {/* Ambient Background Glow paths */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/20 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-rose-600/20 rounded-full blur-2xl pointer-events-none" />
            
            <div className="relative">
              <span className="px-2.5 py-1 bg-white/10 rounded-full text-[10px] font-bold tracking-widest uppercase mb-4 inline-block text-white/80">
                DAILY MINDSET MOTTO
              </span>
              <p className="text-xl sm:text-2xl font-semibold leading-relaxed tracking-wide text-slate-100 mt-2 font-display">
                {currentMotto}
              </p>
            </div>

            <div className="relative border-t border-white/10 pt-4 mt-6">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🧠</span>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase">時間生物學（Chronobiology）</h4>
                  <p className="text-[11px] text-white/60">人體在清晨、中午與日落後，消化道血流量與升糖胰島素的受體敏感度呈現完全不同的波動。</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* ----------------- SECTION 4: AI CUSTOM HABIT BUILDER (GEMINI INTEGRATION) ----------------- */}
        <div id="ai-generator-panel" className="mt-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
          
          {/* Sparkly design accent */}
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none text-indigo-800">
            <Sparkles className="w-56 h-56" />
          </div>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-950 flex items-center gap-2">
                <Sparkles className="w-5.5 h-5.5 text-indigo-600" />
                <span>3. 透過 AI 進行創意思考：為您良身打造專屬飲食時序</span>
              </h3>
              <p className="text-slate-500 text-xs sm:text-sm mt-1">
                輸入您的日常作息、食物偏好、特別嘴饞的時段（例如下午四點想吃甜點），讓 Gemini 依據生理時鐘，自訂生成您的 X-Y 時間序列矩陣。
              </p>
            </div>
            
            <div className="flex-shrink-0 bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100 text-[11px] text-indigo-800 font-semibold">
              採用 Gemini 3.5 智慧模型推薦
            </div>
          </div>

          {/* Preset templates for user input */}
          <div className="mb-6">
            <span className="text-xs font-bold text-slate-400 block mb-2">💡 快捷點選：快速載入壓力痛點情境</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => applyPreset(p)}
                  className="p-3 text-left bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition text-xs flex flex-col justify-between"
                >
                  <div>
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold uppercase mb-1 ${
                      p.goal === "健康" ? "bg-emerald-100 text-emerald-800" : p.goal === "減重" ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"
                    }`}>
                      {p.goal}情境
                    </span>
                    <p className="text-slate-700 font-semibold line-clamp-2 leading-relaxed mb-2">
                      「{p.profile}」
                    </p>
                  </div>
                  <span className="text-[10px] text-indigo-700 font-bold self-end flex items-center gap-0.5">
                    套用範例 <ArrowRight className="w-3 h-3" />
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleGetAIRecommendation} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  日常飲食模式或您面臨的飲食難題 (如胃部不適、暴飲暴食)
                </label>
                <textarea
                  value={userProfile}
                  onChange={(e) => setUserProfile(e.target.value)}
                  placeholder="例如：我下午4-5點下班前超級想吃甜食，晚上回家一邊加班一邊吃炸物才覺得紓壓。或者：常常狼吞虎嚥，吃飽飯胃很容易脹氣起酸水。"
                  rows={3}
                  className="w-full text-sm p-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white placeholder-slate-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  您目前特定的正餐、零嘴或水分補充習慣 (選填)
                </label>
                <textarea
                  value={currentHabit}
                  onChange={(e) => setCurrentHabit(e.target.value)}
                  placeholder="例如：習慣一邊吃飯一邊配冰手搖奶茶或果汁。或者：喜歡在睡前吃香蕉或是喝一杯牛奶。"
                  rows={3}
                  className="w-full text-sm p-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white placeholder-slate-400"
                />
              </div>
            </div>

            {/* Error messaging state */}
            {aiError && (
              <div className="p-3 bg-red-50 text-red-800 hover:bg-red-100 rounded-xl border border-red-100 text-xs leading-relaxed flex items-center gap-2">
                <span className="text-sm">⚠️</span>
                <span>{aiError}</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
              <div className="text-[11px] text-slate-400">
                * 本決策表僅供自主建立健康習慣、創意思考輔助。如有重病或腸胃潰瘍者請諮詢醫師或藥師。
              </div>

              <div className="flex items-center gap-3 self-end">
                {isCustomActive && (
                  <button
                    type="button"
                    onClick={handleResetToDefault}
                    className="px-4 py-2 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-xl transition"
                  >
                    恢復預設經典表
                  </button>
                )}
                
                <button
                  type="submit"
                  disabled={loadingAI}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-sm font-bold rounded-xl transition shadow-md hover:shadow-lg flex items-center gap-2"
                  id="submit-ai-generator-btn"
                >
                  {loadingAI ? (
                    <>
                      <span className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent inline-block"></span>
                      <span>AI 生生化原理思考中...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>AI 客製化我的飲食序對照表</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>

        </div>

        {/* -------------------- SECTION 5: MY HABITS ACTION LIST -------------------- */}
        <div className="mt-8 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-950 flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-indigo-600" />
                <span>我的膳食時序微習慣實踐清單（持續儲存於本地）</span>
              </h3>
              <p className="text-slate-500 text-xs">
                點擊上方案例，即可一鍵將特定時間順序底下的創意點子加入下表，督促自己每日執行、勾選，守護您的減重與健康。
              </p>
            </div>

            {/* Completion Rates */}
            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold block">COMPLETION RATE</span>
                <span className="text-lg font-black text-slate-900">
                  {habits.length > 0 
                    ? Math.round((habits.filter(h => h.completed).length / habits.length) * 100)
                    : 0}%
                </span>
              </div>
              <div className="w-32 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-600 rounded-full transition-all duration-300" 
                  style={{ 
                    width: `${habits.length > 0 ? (habits.filter(h => h.completed).length / habits.length) * 100 : 0}%` 
                  }}
                />
              </div>
            </div>
          </div>

          {/* Quick simple text adder */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 mb-4">
            <div className="flex flex-col sm:flex-row gap-2 max-w-4xl">
              <input
                id="manual-habit-input"
                type="text"
                placeholder="自訂習慣（如：吃午餐前喝 300ml 暖胃紅茶）"
                className="flex-1 text-sm bg-white border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <select
                id="manual-habit-phase"
                className="text-sm bg-white border border-slate-300 rounded-lg px-2 py-2 focus:outline-none"
              >
                <option value="吃飯前">吃飯前</option>
                <option value="吃飯中">吃飯中</option>
                <option value="吃飯後">吃飯後</option>
              </select>
              <button
                onClick={() => {
                  const input = document.getElementById("manual-habit-input") as HTMLInputElement;
                  const phase = document.getElementById("manual-habit-phase") as HTMLSelectElement;
                  if (input && input.value.trim()) {
                    handleAddHabit(input.value, phase.value, selectedGoal);
                    input.value = "";
                  }
                }}
                className="px-4 py-2 bg-slate-900 border border-slate-900 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-1 hover:bg-slate-800 transition"
                id="add-habit-manual-btn"
              >
                <Plus className="w-4 h-4" />
                <span>加入實踐清單</span>
              </button>
            </div>
          </div>

          {/* Habits grid listing */}
          {habits.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs tracking-wide">
              目前清單為空。歡迎在上方的流程圖中點擊卡片，並點選「加入每日清單」將創意食材方案加到這裡！
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {habits.map((item) => (
                <div 
                  key={item.id}
                  className="py-3 flex items-center justify-between gap-4 group/item hover:bg-slate-50/40 px-2 rounded-lg transition"
                >
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <button
                      onClick={() => handleToggleHabit(item.id)}
                      className={`mt-0.5 w-5 h-5 flex items-center justify-center rounded-md border flex-shrink-0 transition-colors ${
                        item.completed
                          ? "bg-indigo-600 border-indigo-600 text-white"
                          : "border-slate-300 hover:border-indigo-500"
                      }`}
                      id={`toggle-habit-${item.id}`}
                    >
                      {item.completed && <Check className="w-3.5 h-3.5" />}
                    </button>
                    <div className="min-w-0">
                      <p className={`text-sm leading-relaxed ${item.completed ? "line-through text-slate-400" : "text-slate-800 font-medium"}`}>
                        {item.text}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 text-[9px] font-bold">
                          {item.phase}
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 text-[9px] font-bold">
                          目標：{item.goal}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteHabit(item.id)}
                    className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover/item:opacity-100 transition-opacity"
                    id={`delete-habit-${item.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

        </div>

      </main>

      {/* -------------------- DETAIL INSPECTOR MODAL OVERLAY -------------------- */}
      <AnimatePresence>
        {inspectorCell && (() => {
          const { phase, category } = inspectorCell;
          const phaseMeta = phaseLabels[phase];
          const catMeta = categoryLabels[category];
          const cell = getCellContent(phase, category);

          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              {/* Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setInspectorCell(null)}
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs"
              />

              {/* Card Container */}
              <motion.div 
                initial={{ scale: 0.95, y: 15, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.95, y: 15, opacity: 0 }}
                className="bg-white rounded-2xl shadow-xl w-full max-w-xl overflow-hidden relative z-10 border border-slate-100"
              >
                
                {/* Header banner */}
                <div className={`p-5 ${currentTheme.lightBg} border-b border-slate-100 flex items-center justify-between`}>
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{phaseMeta.emoji}</span>
                    <div>
                      <span className="text-[10px] text-slate-400 font-black tracking-widest uppercase block mb-0.5">TIMING DECISION ADVISOR</span>
                      <h4 className="text-lg font-black text-slate-950 font-display">
                        時序坐標：{phaseMeta.label} × {catMeta.label}
                      </h4>
                    </div>
                  </div>
                  <button 
                    onClick={() => setInspectorCell(null)}
                    className="p-1.5 text-slate-400 hover:text-slate-800 hover:bg-slate-200/50 rounded-full transition"
                    id="close-inspector-modal-btn"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Content body */}
                <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
                  
                  {/* Food Card */}
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
                      建議食材與方案食物 (Y軸)
                    </span>
                    <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <span className="text-2xl">{catMeta.emoji}</span>
                      <span>{cell.title}</span>
                    </h3>
                  </div>

                  {/* Behavioral description */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                      💡 核心實作做法與創意說明 (X軸時序關聯)
                    </h5>
                    <p className="text-sm text-slate-700 leading-relaxed bg-amber-50/30 p-3 rounded-lg border border-amber-100/50">
                      {cell.desc}
                    </p>
                  </div>

                  {/* Mechanism */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <Activity className="w-4 h-4 text-emerald-600" />
                      <span>🩸 為什麼在這個時間點？（食物消化學理與荷爾蒙反應）</span>
                    </h5>
                    <div className="text-xs text-slate-600 leading-relaxed space-y-2">
                      {phase === "beforeMeal" && (
                        <p>
                          <strong>餐前 15-30 分鐘：</strong>此時胃酸處於基礎分泌狀態，適量的水分（特別是溫茶或草本茶）能充分喚醒迷走神經，放鬆腹腔。
                          如果是零食或水果，能在正餐前 20 分鐘刺激胃分泌膽囊收縮素（CCK）或胰高血糖素樣肽-1（GLP-1），提前通知腦下垂體降低稍後吃飯的狂熱需求，是減重與血糖控制的第一關鍵。
                        </p>
                      )}
                      {phase === "duringMeal" && (
                        <p>
                          <strong>餐中（進餐期間）：</strong>此時胃酸分泌量達到高峰（pH 值降至 1.5 - 2），這對於降菌、消化高分子量的蛋白質（如牛肉、魚類）極其重要。
                          此時若是大口灌水或吃多汁水果，會直接稀釋胃酸，拉長消化滯留時間，導致發酵產氣。故餐中提倡乾濕分離，僅將微量天然果酸（如蘋果絲、檸檬汁）當成前菜佐料，能極佳地加速鐵質轉化。
                        </p>
                      )}
                      {phase === "afterMeal" && (
                        <p>
                          <strong>餐後 20 分鐘至一小時：</strong>正餐的碳水化合物和蛋白質開始進入十二指腸進行吸收。
                          此時大腦的多巴胺與餐後胰島素回饋，常引發「情緒性嘴饞（想吃高熱量甜點）」。本時序在飯後引入極乾淨的去油茶多酚，其能將舌頭表面的味蕾乳突「物理性封閉」，並利用黑可可粉平撫皮質醇，瞬間給飲食寫上終止句。
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Creative Swaps */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <Heart className="w-4 h-4 text-rose-500" />
                      <span>替換代方案與創意行為</span>
                    </h5>
                    <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100/40 text-xs text-indigo-950 leading-relaxed">
                      {category === "snacks" && "若臨時找不到該食材，可用 1 大茶匙的原味黃金亞麻籽、冷乾海苔片、或是 1 杯淡淡的菊花無糖茶來充實腹部，均能達到相同的交感神經放鬆效果。"}
                      {category === "water" && "若不喜歡淡茶，可將常溫開水替代為新鮮萊姆水果片、切片乾薑水、或是微量薄荷葉泡水，利用植物精精油成分，促進下消化道的推進力。"}
                      {category === "fruit" && "若該水果非當令，可用抗氧化力高且低 GI 的聖女小番茄、小蓮霧或新鮮大藍莓替代，不吃甜度過高的水果（如芒果、熟度過高的香蕉），避免血糖暴起暴落。"}
                    </div>
                  </div>

                </div>

                {/* Footer action */}
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="text-[10px] text-slate-400">
                    時序目標：<strong>{selectedGoal}</strong> 指引
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        handleAddHabit(
                          `【${phaseMeta.label}】實踐：在「${phaseMeta.label}」時段，執行【${cell.title}】的最佳策略`,
                          phaseMeta.label,
                          selectedGoal
                        );
                        setInspectorCell(null);
                      }}
                      className="px-4 py-2 bg-slate-900 border border-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 transition"
                      id="add-via-modal-btn"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>將此策略加入每日實踐清單</span>
                    </button>
                    <button
                      onClick={() => setInspectorCell(null)}
                      className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold rounded-xl text-xs transition"
                    >
                      關閉關聯
                    </button>
                  </div>
                </div>

              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

    </div>
  );
}

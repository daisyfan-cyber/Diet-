export type GoalType = "健康" | "減重" | "情緒";

export interface CellDetail {
  item: string;         // E.g., "無鹽堅果"
  desc: string;         // Explanation of nutritional benefits
  creativeVariant?: string; // Creative variation or beverage substitute
  mechanism?: string;  // Medical or health hormone mechanism
}

export type TimelinePhase = "beforeMeal" | "duringMeal" | "afterMeal";
export type CategoryKey = "snacks" | "water" | "fruit";

export interface TimelineData {
  snacks: string;
  snacksDesc: string;
  water: string;
  waterDesc: string;
  fruit: string;
  fruitDesc: string;
}

export interface RecommendationResponse {
  goal: GoalType;
  analysis: string;
  timeline: {
    beforeMeal: TimelineData;
    duringMeal: TimelineData;
    afterMeal: TimelineData;
  };
  hacks: string[];
  moodBooster: string;
}
